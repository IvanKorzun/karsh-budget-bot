import sqlite3

DB_NAME = "karsh.db"

def init_db():
    with sqlite3.connect(DB_NAME) as conn:
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT UNIQUE,
                username TEXT,
                balance REAL DEFAULT 0.0
            )
        ''')
        conn.commit()

def add_or_update_user(name, username, balance):
    with sqlite3.connect(DB_NAME) as conn:
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO users (name, username, balance) 
            VALUES (?, ?, ?)
            ON CONFLICT(name) DO UPDATE SET balance=excluded.balance, username=excluded.username
        ''', (name, username, balance))
        conn.commit()

def get_all_users():
    with sqlite3.connect(DB_NAME) as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT name, username, balance FROM users")
        return cursor.fetchall()

def get_user_by_name(name):
    with sqlite3.connect(DB_NAME) as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT name, balance FROM users WHERE name = ?", (name,))
        return cursor.fetchone()

def update_balance(name, amount):
    with sqlite3.connect(DB_NAME) as conn:
        cursor = conn.cursor()
        cursor.execute("UPDATE users SET balance = balance + ? WHERE name = ?", (amount, name))
        conn.commit()