import asyncio
import os
from dotenv import load_dotenv
from aiogram import Bot, Dispatcher, types, F
from aiogram.filters import Command
from aiogram.utils.keyboard import InlineKeyboardBuilder
import database as db

load_dotenv()
TOKEN = os.getenv("BOT_TOKEN")
ADMIN_ID = 1893245583  # Твой ID

bot = Bot(token=TOKEN)
dp = Dispatcher()

# Временное хранилище для экипажа
current_crew = {}


def is_admin(user_id: int):
    return user_id == ADMIN_ID


# --- КЛАВИАТУРА ---
def get_crew_keyboard(selected_names):
    builder = InlineKeyboardBuilder()
    users = db.get_all_users()
    for name, tg, bal in users:
        prefix = "✅ " if name in selected_names else ""
        builder.button(text=f"{prefix}{name}", callback_data=f"crew_{name}")
    builder.button(text="🚀 ПОЕХАЛИ!", callback_data="start_drive")
    builder.button(text="❌ ОТМЕНА", callback_data="cancel_trip")
    builder.adjust(2)
    return builder.as_markup()


# --- КОМАНДЫ ---

@dp.message(Command("start"))
async def cmd_start(message: types.Message):
    await message.answer(
        "🚕 <b>Карш-Бухгалтер активен!</b>\n\n"
        "📊 /status — счета\n"
        "➕ /start_trip — начать поездку\n"
        "🏁 /end [сумма] — завершить",
        parse_mode="HTML"
    )


@dp.message(Command("status"))
async def cmd_status(message: types.Message):
    users = db.get_all_users()
    if not users:
        await message.answer("База пуста.")
        return

    text = "📊 <b>Текущие балансы:</b>\n"
    text += "──────────────────\n"
    for name, tg, bal in users:
        bal = round(bal, 2)
        if bal >= 0:
            emoji = "🟢"
            desc = ""
        elif bal <= -2.6:
            emoji = "🔴"
            desc = ""
        else:
            emoji = "⚪"
            desc = " (до 2.6 можно не платить)"
        text += f"{emoji} <b>{name}</b>: {bal:.2f} BYN{desc}\n"
    text += "──────────────────"
    await message.answer(text, parse_mode="HTML")


@dp.message(Command("start_trip"))
async def cmd_start_trip(message: types.Message):
    if not is_admin(message.from_user.id):
        return  # Друзья не могут вызвать само меню кнопок

    current_crew[message.from_user.id] = []
    await message.answer(
        "🚗 <b>Кто сегодня в машине?</b>",
        reply_markup=get_crew_keyboard([]),
        parse_mode="HTML"
    )


# --- ОБРАБОТКА КНОПОК (С ПРОВЕРКОЙ НА АДМИНА) ---

@dp.callback_query(F.data.startswith("crew_"))
async def toggle_crew(callback: types.CallbackQuery):
    if not is_admin(callback.from_user.id):
        await callback.answer("⛔ Это кнопки только для водителя!", show_alert=True)
        return

    name = callback.data.replace("crew_", "")
    selected = current_crew.get(callback.from_user.id, [])
    if name in selected:
        selected.remove(name)
    else:
        selected.append(name)
    current_crew[callback.from_user.id] = selected
    await callback.message.edit_reply_markup(reply_markup=get_crew_keyboard(selected))
    await callback.answer()


@dp.callback_query(F.data == "start_drive")
async def start_drive(callback: types.CallbackQuery):
    if not is_admin(callback.from_user.id):
        await callback.answer("⛔ Не твоя машина — не тебе и заводить!", show_alert=True)
        return

    selected = current_crew.get(callback.from_user.id, [])
    if not selected:
        return await callback.answer("Выбери хотя бы одного человека!", show_alert=True)

    await callback.message.edit_text(
        f"🛣 <b>Поездка началась!</b>\n\n<b>Экипаж:</b> {', '.join(selected)}\n\n"
        f"В конце напиши: <code>/end [сумма]</code>",
        parse_mode="HTML"
    )
    await callback.answer()


@dp.callback_query(F.data == "cancel_trip")
async def cancel_trip(callback: types.CallbackQuery):
    if not is_admin(callback.from_user.id):
        await callback.answer("⛔ Отменить поездку может только водитель.", show_alert=True)
        return

    current_crew.pop(callback.from_user.id, None)
    await callback.message.edit_text("🚫 Поездка отменена.")
    await callback.answer()


# --- ОСТАЛЬНЫЕ КОМАНДЫ ---

@dp.message(Command("end"))
async def cmd_end_trip(message: types.Message):
    if not is_admin(message.from_user.id): return
    selected = current_crew.get(message.from_user.id)
    if not selected:
        return await message.reply("Сначала начни поездку через /start_trip")

    args = message.text.split()
    if len(args) < 2:
        return await message.reply("Введи итоговую сумму карша.\nПример: <code>/end 12.5</code>", parse_mode="HTML")

    try:
        total = float(args[1].replace(',', '.'))
        share = round(total / (len(selected) + 1), 2)
        for name in selected:
            db.update_balance(name, -share)

        res = f"🏁 <b>Поездка рассчитана!</b>\n\n"
        res += f"💰 Сумма: {total:.2f} BYN\n"
        res += f"💳 С каждого: <b>{share:.2f} BYN</b>\n\n"
        res += "Балансы в базе обновлены."
        await message.answer(res, parse_mode="HTML")
        current_crew.pop(message.from_user.id)
    except ValueError:
        await message.reply("Сумма должна быть числом!")


@dp.message(Command("pay"))
async def cmd_pay(message: types.Message):
    if not is_admin(message.from_user.id): return
    args = message.text.split()
    if len(args) < 3: return
    try:
        name, amount = args[1], float(args[2].replace(',', '.'))
        db.update_balance(name, amount)
        await message.answer(f"✅ Баланс <b>{name}</b> пополнен на {amount:.2f} BYN", parse_mode="HTML")
    except:
        await message.answer("Ошибка в команде.")


async def main():
    print("Бот запущен!")
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())